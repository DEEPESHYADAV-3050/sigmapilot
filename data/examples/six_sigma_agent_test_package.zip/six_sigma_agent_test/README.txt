SIX SIGMA DMAIC AGENT TEST DATASET
===================================
Purpose: Synthetic data package for testing a Six Sigma/DMAIC analysis agent.
All data and company details are simulated, not actual company records.

Product: Precision shaft
LSL = 19.90 mm | Target = 20.00 mm | USL = 20.10 mm

Files:
- baseline_diameter.csv: 100 baseline measurements, 8 defects by design.
- production_context.csv: machine/shift/tool/temperature/setup context.
- gauge_rr.csv: 10 parts x 3 appraisers x 2 trials = 60 readings.
- root_cause_data.csv: context for root-cause exploration; simulated relationships.
- improvement_pilot.csv: 2x2 pilot, 10 observations per factor combination.
- post_improvement.csv: 100 synthetic post-improvement readings, 1 defect by design.
- daily_quality.csv: 30 daily subgroups, 100 units per subgroup.
- financial_model.csv: illustrative financial assumptions.
- data_dictionary.csv: field definitions.
- project_charter.json: machine-readable project charter.
- agent_test_prompt.md: prompt to give your agent.

Cautions:
1. All datasets are simulated.
2. Associations in synthetic observational data do not prove causation.
3. Gauge R&R should use an appropriate crossed method.
4. Capability indices require an adequate measurement system and a stable process.
5. 100 observations may be insufficient to estimate a low defect rate precisely.
6. State the convention if using a 1.5-sigma shift.
7. Control limits are calculated from process data and are not specification limits.
