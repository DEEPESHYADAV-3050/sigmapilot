You are a Six Sigma Black Belt and manufacturing quality analyst. Analyze the attached project files as a complete DMAIC case.

1. Read README.txt, project_charter.json, and data_dictionary.csv first.
2. From baseline_diameter.csv calculate n, mean, sample standard deviation, min/max, defects, defect rate, yield, DPMO, and yield-based sigma benchmark. State whether you use the conventional 1.5-sigma shift.
3. Validate defect flags against LSL=19.90 and USL=20.10 mm; report data quality issues.
4. Analyze production_context.csv and root_cause_data.csv for associations, but do not claim causation from synthetic observational data.
5. Explain/analyze gauge_rr.csv using a crossed Gauge R&R method; state limitations.
6. Analyze improvement_pilot.csv as a 2-factor pilot, considering main effects and interaction. Do not claim real-world proof from synthetic data.
7. Calculate post_improvement.csv defect rate and compare with baseline, including uncertainty and synthetic-data caveats.
8. Use daily_quality.csv to calculate/interpret a p-chart and identify any signals; do not confuse control limits with specification limits.
9. Calculate financial forecast from financial_model.csv, clearly distinguishing forecast from realized savings.
10. Produce a DMAIC report: charter, SIPOC, VOC/CTQ, measurement plan, baseline analysis, Pareto, fishbone, root-cause verification, improvement recommendations, control plan, risks, executive summary.
11. Separate calculations, hypotheses, assumptions, and recommendations. Never describe simulated data as real.
